Instructions for Plugin Setup
========================================================================

Step 1 - Copy the plugin into your plugins folder inside wp-content folder.

Step 2 - Activate the plugin through admin dashboard.

Step 3 - Manually enter the following link on browser by replacing example.com with your site.
     		http://www.example.com/user/register

	 If you are working locally your URL might look like the following
     		http://localhost/folder name/user/register

Step 4 - If you get 404 page not found error, make sure to set the permalinks to postname (http://www.example.com/sample-post/) and save them again.

Step 5 - Then complete the registration and you will be redirected to login form on successful registration.

Step 6 - Go to your email inbox and click on the activation link sent with the registration success message.

Step 7 - You will be redirected to application with successfully activated message.

Step 8 - Then type http://www.example.com/user/login in browser to load the login page.

Step 9 - Finally, use the username and passowrd to login and you will be redirected to application home page on successful authentication
