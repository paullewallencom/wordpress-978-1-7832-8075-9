<?php


class WPWA_Admin_Theme {

    public function __construct() {
      //  add_action('admin_enqueue_scripts', array($this, 'wpwa_admin_theme_style'));
        //add_action('login_enqueue_scripts', array($this, 'wpwa_admin_theme_style'));
    }

    

}

//$admin_theme = new WPWA_Admin_Theme();


